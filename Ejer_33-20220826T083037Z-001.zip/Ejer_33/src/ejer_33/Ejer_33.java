package ejer_33;

import java.util.*;

public class Ejer_33 {

    public static void main(String[] args) {
        Scanner nume = new Scanner (System.in);
        double nota;
        
        System.out.println("Digite su nota del examen");
        nota = nume.nextDouble();
       
        if (nota<3.0) {
            System.out.println("BAJO");

        } else if (nota>3.0 && nota<3.7) {
            System.out.println("BÁSICO");

        } else if (nota>3.8 && nota<4.2) {
            System.out.println("ALTO");

        } else if (nota>4.3 && nota<5.0) {
            System.out.println("SUPERIOR");
            
        }else {
            System.out.println("La nota registrada debe ser solo de 0.0 a 5.0");
        }
    } 
}
        
          